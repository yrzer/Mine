function on_wczytywanie(str) {
let main =    document.getElementsByClassName('main');
let cena = document.getElementById('cena');
let zniszka = document.getElementById('zniszka');
if(str==1){ // audi
    
}
if(str==2){ // citroen
    cena.value = "30999";
}
if(str==3){ // honda
    cena.value = "19900";
    zniszka.innerHTML =  '<br>zniszka 30% <input type="checkbox" id="ch_zniszka"><br>';
}
}
function zmien() {
    let cena = parseFloat(document.getElementById('cena').value);
    let ilosc = parseFloat(document.getElementById('ilosc').value);
    let czy;
    try {
        czy = document.getElementById('ch_zniszka').checked;
        if(czy == 1){
            cena = cena - cena*0.3;
        }
    } catch (error) {
        
    }
    let odp = "do zaplaty= "+cena*ilosc;

    if(ilosc>=0){
        
        

    }else{
        odp = "error"
    }

    alert(odp);

}